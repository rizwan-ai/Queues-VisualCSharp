﻿using System;
using static System.Console;
using static System.Convert;

namespace DEQUE
{
    class Program
    {
        static void Main(string[] args)
        {
            Deque dq = new Deque(5);
            dq.EnqueueFront(2);
            //dq.Display();
            //dq.EnqueueFront(4);
            dq.EnqueueRear(4);
            dq.EnqueueRear(6);
            dq.EnqueueRear(8);
            dq.EnqueueRear(10);
            //dq.Display();
            //dq.EnqueueRear(12);
            dq.DequeueFront();
            dq.DequeueFront();
            dq.DequeueFront();
            dq.EnqueueFront(12);
            dq.EnqueueFront(14);
            dq.EnqueueFront(16);
            //dq.EnqueueFront(18);
            //dq.Display();
            dq.DequeueRear();
            dq.DequeueRear();
            dq.Display();
            dq.EnqueueFront(18);

            ReadKey();
        }
    }
}
