﻿using System;
using static System.Console;
using static System.Convert;

namespace LinearQueue
{
    class Program
    {
        static void Main(string[] args)
        {
            Title = "Linear Queue";

            Write("Enter Length of the Queue : ");
            int length = ToInt32(ReadLine());

            LinearQ linearQ = new LinearQ(length);

            bool flag = true;
            while (flag)
            {
                Clear();
                WriteLine("1 - Insert value into Queue");
                WriteLine("2 - Remove value from Queue");
                WriteLine("3 - Display values from Queue");
                WriteLine("4 - Peek value of the Queue");
                WriteLine("5 - Check if Queue Is-Full");
                WriteLine("6 - Check if Queue Is-Empty");
                WriteLine("7 - Exit");
                Write("Enter your option : ");
                int op = ToInt32(ReadLine());
                switch (op)
                {
                    case 1:
                        Write("Enter value to Insert : ");
                        int val = ToInt32(ReadLine());
                        linearQ.Enqueue(val);
                        ReadKey();
                        break;
                    case 2:
                        linearQ.Dequeue();
                        ReadKey();
                        break;
                    case 3:
                        linearQ.Display();
                        ReadKey(); 
                        break;
                    case 4:
                        WriteLine(linearQ.Peek());
                        ReadKey();
                        break;
                    case 5:
                        WriteLine(linearQ.IsFull());
                        ReadKey();
                        break;
                    case 6:
                        WriteLine(linearQ.IsEmpty());
                        ReadKey();
                        break;
                    case 7:
                        flag = false;
                        break;
                    default:
                        WriteLine("Invalid option");
                        ReadKey();
                        break;
                }
            }

            ReadKey(true);
        }
    }
}