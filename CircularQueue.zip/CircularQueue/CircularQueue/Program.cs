﻿using System;
using static System.Console;
using static System.Convert;

namespace CircularQueue
{
    class Program
    {
        static void Main(string[] args)
        {
            Title = "Circular Queue";

            Write("Enter Length of the Queue : ");
            int length = ToInt32(ReadLine());

            CircularQ circularQ = new CircularQ(length);
            
            bool flag = true;
            while (flag)
            {
                Clear();
                WriteLine("1 - Insert value into Queue");
                WriteLine("2 - Remove value from Queue");
                WriteLine("3 - Exit");
                Write("Enter your option : ");
                int op = ToInt32(ReadLine());
                switch (op)
                {
                    case 1:
                        Write("Enter value to Insert : ");
                        int val = ToInt32(ReadLine());
                        circularQ.Enqueue(val);
                        ReadKey();
                        break;
                    case 2:
                        circularQ.Dequeue();
                        ReadKey();
                        break;
                    case 3:
                        flag = false;
                        break;
                    default:
                        WriteLine("Invalid option");
                        ReadKey();
                        break;
                }
            }

            ReadKey(true);
        }
    }
}